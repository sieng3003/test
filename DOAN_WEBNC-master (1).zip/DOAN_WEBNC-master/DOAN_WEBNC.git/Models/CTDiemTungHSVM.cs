﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace DOAN_WEBNC.Models
{
    public class CTDiemTungHSVM
    {
        public int MaBangDiem { get; set; }
        public string TenMon { get; set; }
        public double DiemTong { get; set; }
    }
}