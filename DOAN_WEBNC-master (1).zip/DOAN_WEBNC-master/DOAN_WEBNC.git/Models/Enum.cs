﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOAN_WEBNC.Models
{
    public enum TenHocKy
    {
        HK1,
        HK2
    }
    public enum GioiTinh { 
        Nam,
        Nữ
    }
    public enum TenLoaiDiem
    {
        Loai1,
        Loai2, 
        Loai3,
        THI,
        TBHK,    
        TBNH
    }
}