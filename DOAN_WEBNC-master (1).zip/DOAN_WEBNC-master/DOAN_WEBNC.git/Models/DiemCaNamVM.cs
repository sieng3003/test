﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DOAN_WEBNC.Models
{
    public class DiemCaNamVM
    {
        public string TenMH { get; set; }
        public double DiemTBCN { get; set; }
    }
}